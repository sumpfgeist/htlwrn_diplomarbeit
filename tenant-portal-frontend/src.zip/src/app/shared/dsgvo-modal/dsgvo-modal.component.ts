import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule, ModalController } from '@ionic/angular';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-dsgvo-modal',
  standalone: true,
  imports: [CommonModule, IonicModule, TranslateModule],
  templateUrl: './dsgvo-modal.component.html',
  styleUrls: ['./dsgvo-modal.component.scss'],
})
export class DsgvoModalComponent {
  constructor(private modalCtrl: ModalController) {}

  dismiss(accepted: boolean) {
    this.modalCtrl.dismiss(accepted);
  }
}
