import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { TranslateModule } from '@ngx-translate/core';

import { AuthService } from '../../services/auth.service';
import { DsgvoService } from '../../services/dsgvo.service';

@Component({
  selector: 'app-dsgvo',
  standalone: true,
  imports: [CommonModule, IonicModule, TranslateModule],
  templateUrl: './dsgvo.page.html',
  styleUrls: ['./dsgvo.page.scss'],
})
export class DsgvoPage {
  busy = false;

  constructor(
    private dsgvo: DsgvoService,
    private auth: AuthService,
    private router: Router
  ) {}

  async accept() {
    if (this.busy) return;
    this.busy = true;

    this.dsgvo.accept();
    await this.router.navigateByUrl('/tabs/dashboards', { replaceUrl: true });
  }

  async decline() {
    if (this.busy) return;
    this.busy = true;

    // “Ablehnen” heißt: kein Zugriff.
    this.dsgvo.clear();
    this.auth.logout();
    await this.router.navigateByUrl('/login', { replaceUrl: true });
  }
}
