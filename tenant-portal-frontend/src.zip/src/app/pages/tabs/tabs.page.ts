import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { RouterOutlet } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-tabs',
  standalone: true,
  imports: [IonicModule, RouterOutlet, TranslateModule],
  templateUrl: './tabs.page.html',
})
export class TabsPage {}
