import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { IonicModule, ModalController, ToastController } from '@ionic/angular';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

import { AuthService } from '../../services/auth.service';
import { DsgvoModalComponent } from '../../shared/dsgvo-modal/dsgvo-modal.component';

const DSGVO_KEY = 'tp_dsgvo_accepted';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, IonicModule, FormsModule, TranslateModule],
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {
  username = '';
  password = '';
  showPw = false;
  loading = false;

  constructor(
    private auth: AuthService,
    private router: Router,
    private modalCtrl: ModalController,
    private toastCtrl: ToastController,
    private i18n: TranslateService
  ) {}

  async login() {
    if (!this.username || !this.password) {
      await this.toast('LOGIN.FILL_ALL');
      return;
    }

    this.loading = true;
    this.auth.login(this.username, this.password).subscribe({
      next: async () => {
        this.loading = false;

        const accepted = localStorage.getItem(DSGVO_KEY) === 'true';
        if (!accepted) {
          const modal = await this.modalCtrl.create({
            component: DsgvoModalComponent,
            backdropDismiss: false,
          });
          await modal.present();

          const result = await modal.onWillDismiss<boolean>();
          if (result.data === true) {
            localStorage.setItem(DSGVO_KEY, 'true');
            localStorage.setItem('tp_dsgvo_accepted_at', new Date().toISOString());
            await this.router.navigateByUrl('/tabs/dashboards');
          } else {
            this.auth.logout();
            await this.toast('DSGVO.MUST_ACCEPT');
          }
          return;
        }

        await this.router.navigateByUrl('/tabs/dashboards');
      },
      error: async () => {
        this.loading = false;
        await this.toast('LOGIN.ERROR');
      },
    });
  }

  async openDsgvo() {
    const modal = await this.modalCtrl.create({
      component: DsgvoModalComponent,
    });
    await modal.present();
  }

  private async toast(key: string) {
    const msg = this.i18n.instant(key);
    const t = await this.toastCtrl.create({ message: msg, duration: 2000 });
    await t.present();
  }
}
