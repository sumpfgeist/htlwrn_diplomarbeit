import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { IonicModule, ToastController } from '@ionic/angular';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

import { AuthService } from '../../services/auth.service';
import { DsgvoService } from '../../services/dsgvo.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule, TranslateModule],
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {
  username = '';
  password = '';
  loading = false;

  constructor(
    private auth: AuthService,
    private router: Router,
    private toastCtrl: ToastController,
    private translate: TranslateService,
    private dsgvo: DsgvoService
  ) {}

  async login() {
    if (!this.username || !this.password) {
      await this.toast('LOGIN.ERROR_MISSING_FIELDS');
      return;
    }

    this.loading = true;

    this.auth.login(this.username, this.password).subscribe({
      next: async () => {
        this.loading = false;

        // DSGVO nicht per Modal, sondern als eigene Seite
        if (!this.dsgvo.isAccepted()) {
          await this.router.navigateByUrl('/dsgvo', { replaceUrl: true });
          return;
        }

        await this.router.navigateByUrl('/tabs/dashboards', { replaceUrl: true });
      },
      error: async () => {
        this.loading = false;
        await this.toast('LOGIN.ERROR_INVALID');
      },
    });
  }

  private async toast(key: string) {
    const message = this.translate.instant(key);
    const toast = await this.toastCtrl.create({
      message,
      duration: 2000,
      position: 'bottom',
    });
    await toast.present();
  }
}
