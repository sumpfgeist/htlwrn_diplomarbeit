import { Component, OnDestroy, inject } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { NavigationEnd, Router } from '@angular/router';
import { filter, Subscription } from 'rxjs';

import { addIcons } from 'ionicons';
import {
  analyticsOutline,
  documentTextOutline,
  logOutOutline,
  personCircleOutline,
  closeOutline,
  chevronBackOutline,
  chevronForwardOutline,
  eyeOutline,
  eyeOffOutline,
  personOutline,
} from 'ionicons/icons';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [IonicModule],
  templateUrl: './app.component.html',
})
export class AppComponent implements OnDestroy {
  private router = inject(Router);
  private sub: Subscription;

  constructor() {
    // Icons registrieren (sonst Warning-Spam)
    addIcons({
      'analytics-outline': analyticsOutline,
      'document-text-outline': documentTextOutline,
      'log-out-outline': logOutOutline,
      'person-circle-outline': personCircleOutline,
      'close-outline': closeOutline,
      'chevron-back-outline': chevronBackOutline,
      'chevron-forward-outline': chevronForwardOutline,
      'eye-outline': eyeOutline,
      'eye-off-outline': eyeOffOutline,
      'person-outline': personOutline,
    });

    this.sub = this.router.events
      .pipe(filter((e) => e instanceof NavigationEnd))
      .subscribe(() => this.cleanupGhostOverlays());
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  private cleanupGhostOverlays(): void {
    if (typeof document === 'undefined') return;

    const overlaySelector =
      'ion-modal, ion-alert, ion-popover, ion-loading, ion-action-sheet, ion-picker, ion-toast';

    // Unsichtbare Overlays entfernen, die sonst Klicks blocken können
    document.querySelectorAll(overlaySelector).forEach((el) => {
      const node = el as any;
      const htmlEl = el as HTMLElement;

      const ariaHidden = htmlEl.getAttribute('aria-hidden') === 'true';
      const style = window.getComputedStyle(htmlEl);
      const hidden =
        style.display === 'none' ||
        style.visibility === 'hidden' ||
        style.opacity === '0';

      if (ariaHidden || hidden) {
        try {
          node.dismiss?.();
        } catch {}
        try {
          node.remove?.();
        } catch {}
      }
    });

    // Backdrops, die noch Klicks abfangen, entwaffnen / entfernen
    document.querySelectorAll('ion-backdrop').forEach((bd) => {
      const backdrop = bd as HTMLElement;
      const ariaHidden = backdrop.getAttribute('aria-hidden') === 'true';
      const style = window.getComputedStyle(backdrop);
      const hidden =
        style.display === 'none' ||
        style.visibility === 'hidden' ||
        style.opacity === '0';

      const insideOverlay = backdrop.closest(overlaySelector);

      if (ariaHidden || hidden) {
        backdrop.style.pointerEvents = 'none';
        if (!insideOverlay) {
          backdrop.remove();
        }
      }
    });
  }
}
