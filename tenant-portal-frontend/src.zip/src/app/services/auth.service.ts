import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, tap } from 'rxjs';

const TOKEN_KEY = 'tp_token';

@Injectable({ providedIn: 'root' })
export class AuthService {
  // TODO: falls ihr ein environment habt, nimm das. So ist es zumindest zentral.
  private readonly baseUrl = 'https://diplo.acurade.systems/api/v1';

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<{ token: string }> {
    // TODO: Endpoint ggf. anpassen.
    // return this.http.post<{ token: string }>(`${this.baseUrl}/auth/login`, { username, password })
    //   .pipe(tap(r => localStorage.setItem(TOKEN_KEY, r.token)));

    // Stub (damit UI & Flow funktionieren):
    return of({ token: 'dev-token' }).pipe(
      tap((r) => localStorage.setItem(TOKEN_KEY, r.token))
    );
  }

  logout() {
    localStorage.removeItem(TOKEN_KEY);
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem(TOKEN_KEY);
  }

  changePassword(oldPassword: string, newPassword: string): Observable<void> {
    // TODO: Endpoint ggf. anpassen.
    // return this.http.post<void>(`${this.baseUrl}/auth/change-password`, { oldPassword, newPassword });

    // Stub:
    return of(void 0);
  }
}
