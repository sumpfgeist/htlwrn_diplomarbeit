import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

const LANG_KEY = 'tp_lang';

@Injectable({ providedIn: 'root' })
export class LanguageService {
  constructor(private translate: TranslateService) {}

  init() {
    this.translate.addLangs(['de', 'en']);

    const stored = localStorage.getItem(LANG_KEY);
    const fallback = 'de';
    const lang = stored && ['de', 'en'].includes(stored) ? stored : fallback;

    this.translate.setDefaultLang(fallback);
    this.translate.use(lang);
  }

  getCurrent(): 'de' | 'en' {
    const cur = this.translate.currentLang || this.translate.defaultLang || 'de';
    return (cur === 'en' ? 'en' : 'de');
  }

  setLanguage(lang: 'de' | 'en') {
    localStorage.setItem(LANG_KEY, lang);
    this.translate.use(lang);
  }
}
