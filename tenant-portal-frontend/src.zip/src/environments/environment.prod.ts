export const environment = {
  production: true,
  apiBaseUrl: 'https://diplo.acurade.systems/api/v1',
};
